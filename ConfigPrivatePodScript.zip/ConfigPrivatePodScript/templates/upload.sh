pod repo push BLRepositories __ProjectName__.podspec --verbose --allow-warnings
